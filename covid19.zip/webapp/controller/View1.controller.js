sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/base/util/each",
	"sap/base/util/merge",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller, each, merge, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("Dev.covid19.controller.View1", {
		onInit: function () {
			this.onCovid19();
		},
		onSearch: function () {
			var userinput = this.getView().byId("id-input").getValue();
			// where Country = "userinput"
			var oFilter = new Filter("Country", FilterOperator.Contains, userinput);
			this.getView().byId("id-table").getBinding("items").filter(oFilter);
		},
		onCovid19: function () {
			var that = this;
			var newArray = new Array();
			var oModel = new sap.ui.model.json.JSONModel();
			this.getData(function (data) {
				each(data.Countries, function (index, countrie) {
					var newData = merge({
						"flag": "png100px/" + countrie.CountryCode.toLowerCase() + ".png"
					}, countrie);
					newArray.push(newData);
				});
				oModel.setSizeLimit(1000);
				oModel.setData(newArray);
				that.getView().setModel(oModel, "covid");
			});
		},
		getData: function (callback) {
			// https://api.covid19api.com/summary
			//ajax
			$.ajax({
				method: "GET",
				"url": "https://api.covid19api.com/summary"
			}).done(function (data) {
				callback(data);
			});
		}

	});
});